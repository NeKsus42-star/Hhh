package com.example.jojostands.entity;

import com.example.jojostands.StandData;
import com.example.jojostands.StandUtil;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Рука стенда. Висит рядом с хозяином, умеет бить и тащить предметы. */
public class EntityStandHand extends EntityLerp {
    private static final DataParameter<Integer> STAND = EntityDataManager.createKey(EntityStandHand.class, DataSerializers.VARINT);
    private static final float[] DMG = {0F, 7F, 10F, 6F};
    private static final double PUNCH_RANGE = 8.0;
    private static final double GRAB_RANGE = 24.0; // предметы берёт дальше, чем бьёт
    private static final int IDLE = 0, GOTO = 1, BACK = 2;

    private UUID ownerId;
    private int state = IDLE;
    private boolean punchMode;
    private Vec3d targetPos;
    private Entity targetEntity;
    private Entity carried;
    private int ticks;

    public EntityStandHand(World w) {
        super(w);
        setSize(0.5F, 0.5F);
        noClip = true;
        ignoreFrustumCheck = true;
    }

    public EntityStandHand(World w, EntityPlayer owner, int type) {
        this(w);
        ownerId = owner.getUniqueID();
        dataManager.set(STAND, type);
        Vec3d p = idlePos(owner);
        setPosition(p.x, p.y, p.z);
        rotationYaw = owner.rotationYaw;
        rotationPitch = owner.rotationPitch;
    }

    @Override
    protected void entityInit() {
        dataManager.register(STAND, 0);
    }

    public int getStandType() {
        return dataManager.get(STAND);
    }

    private static Vec3d idlePos(EntityPlayer o) {
        double yaw = Math.toRadians(o.rotationYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        return new Vec3d(o.posX + rx * 0.8 + fx * 0.9, o.posY + o.getEyeHeight() - 0.4, o.posZ + rz * 0.8 + fz * 0.9);
    }

    // ---------------- команды ----------------
    public void punch(EntityPlayer o) {
        if (state == GOTO) return;
        RayTraceResult r = StandUtil.trace(o, PUNCH_RANGE, e -> e instanceof EntityLivingBase);
        punchMode = true;
        targetEntity = null;
        if (r != null && r.entityHit != null) {
            targetEntity = r.entityHit;
            targetPos = StandUtil.center(r.entityHit);
        } else if (r != null) {
            targetPos = r.hitVec;
        } else {
            targetPos = o.getPositionEyes(1.0F).addVector(o.getLookVec().x * 3, o.getLookVec().y * 3, o.getLookVec().z * 3);
        }
        go();
    }

    public void grab(EntityPlayer o) {
        if (state == GOTO || carried != null) return;
        RayTraceResult r = StandUtil.trace(o, GRAB_RANGE, e -> e instanceof EntityItem);
        if (r == null || r.entityHit == null) {
            o.sendStatusMessage(new TextComponentString("Предмет не найден в прицеле"), true);
            return;
        }
        punchMode = false;
        targetEntity = r.entityHit;
        targetPos = StandUtil.center(r.entityHit);
        go();
    }

    /** Рука просто тянется в точку (жест), без урона. */
    public void gesture(Vec3d pos) {
        if (state == GOTO) return;
        punchMode = true;
        targetEntity = null;
        targetPos = pos;
        go();
    }

    public void thrust(EntityPlayer o) {
        Vec3d l = o.getLookVec();
        gesture(o.getPositionEyes(1.0F).addVector(l.x * 3, l.y * 3, l.z * 3));
    }

    private void go() {
        state = GOTO;
        ticks = 0;
    }

    // ---------------- логика ----------------
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            lerpClient();
            return;
        }
        EntityPlayer owner = ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
        if (owner == null || owner.isDead || StandData.get(owner) != getStandType()) {
            setDead();
            return;
        }
        Vec3d idle = idlePos(owner);
        if (getDistanceSq(idle.x, idle.y, idle.z) > 2500.0) {
            setPosition(idle.x, idle.y, idle.z);
            state = IDLE;
            release(owner);
        }

        switch (state) {
            case GOTO:
                if (targetEntity != null) {
                    if (targetEntity.isDead) {
                        state = BACK;
                        break;
                    }
                    targetPos = StandUtil.center(targetEntity);
                }
                face(targetPos.x - posX, targetPos.y - posY, targetPos.z - posZ);
                if (step(targetPos, 1.3)) {
                    arrive(owner);
                    state = BACK;
                } else if (++ticks > 80) {
                    state = BACK;
                }
                break;
            case BACK:
                if (step(idle, 1.6)) {
                    state = IDLE;
                    release(owner);
                }
                break;
            default:
                double d = Math.sqrt(getDistanceSq(idle.x, idle.y, idle.z));
                step(idle, Math.max(0.3, d * 0.4));
                rotationYaw = owner.rotationYaw;
                rotationPitch = owner.rotationPitch;
        }

        if (carried != null) {
            if (carried.isDead) {
                carried = null;
            } else {
                carried.setPosition(posX, posY, posZ);
                carried.motionX = 0;
                carried.motionY = 0;
                carried.motionZ = 0;
                if (carried instanceof EntityItem) ((EntityItem) carried).setPickupDelay(20);
            }
        }
    }

    private void arrive(EntityPlayer owner) {
        if (punchMode) {
            if (targetEntity != null && !targetEntity.isDead) {
                targetEntity.attackEntityFrom(DamageSource.causePlayerDamage(owner), DMG[MathHelper.clamp(getStandType(), 0, 3)]);
                if (targetEntity instanceof EntityLivingBase) {
                    ((EntityLivingBase) targetEntity).knockBack(owner, 1.0F, owner.posX - targetEntity.posX, owner.posZ - targetEntity.posZ);
                }
            }
            ((WorldServer) world).spawnParticle(EnumParticleTypes.CRIT, posX, posY, posZ, 10, 0.3, 0.3, 0.3, 0.3);
            world.playSound(null, posX, posY, posZ, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 1.0F, 1.0F);
        } else if (targetEntity instanceof EntityItem && !targetEntity.isDead) {
            carried = targetEntity;
            carried.setNoGravity(true);
        }
    }

    /** Приносит предмет хозяину: кладём к его ногам, подбор сработает сам. */
    private void release(EntityPlayer owner) {
        if (carried != null && !carried.isDead) {
            carried.setNoGravity(false);
            carried.setPosition(owner.posX, owner.posY + 0.5, owner.posZ);
            if (carried instanceof EntityItem) ((EntityItem) carried).setPickupDelay(0);
        }
        carried = null;
    }

    @Override
    public void setDead() {
        if (!world.isRemote && carried != null && !carried.isDead) {
            carried.setNoGravity(false);
            if (carried instanceof EntityItem) ((EntityItem) carried).setPickupDelay(0);
            carried = null;
        }
        super.setDead();
    }

    private boolean step(Vec3d dest, double speed) {
        Vec3d diff = new Vec3d(dest.x - posX, dest.y - posY, dest.z - posZ);
        double dist = diff.lengthVector();
        if (dist <= speed) {
            setPosition(dest.x, dest.y, dest.z);
            return true;
        }
        setPosition(posX + diff.x / dist * speed, posY + diff.y / dist * speed, posZ + diff.z / dist * speed);
        return false;
    }

    private void face(double dx, double dy, double dz) {
        double h = Math.sqrt(dx * dx + dz * dz);
        if (h + Math.abs(dy) < 1.0E-4) return;
        rotationYaw = (float) (MathHelper.atan2(-dx, dz) * 180.0 / Math.PI);
        rotationPitch = (float) (-MathHelper.atan2(dy, h) * 180.0 / Math.PI);
    }
}
