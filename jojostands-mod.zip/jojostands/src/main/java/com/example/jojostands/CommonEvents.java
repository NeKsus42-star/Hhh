package com.example.jojostands;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.AbstractSkeleton;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Biomes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class CommonEvents {

    // ---------- синхронизация стенда ----------
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.player instanceof EntityPlayerMP) StandData.sync((EntityPlayerMP) e.player);
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.player instanceof EntityPlayerMP) StandData.sync((EntityPlayerMP) e.player);
    }

    @SubscribeEvent
    public void onDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.player instanceof EntityPlayerMP) StandData.sync((EntityPlayerMP) e.player);
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        StandData.setRaw(e.getEntityPlayer(), StandData.get(e.getOriginal()));
    }

    // ---------- скелеты и стрелы стенда ----------
    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent e) {
        World w = e.getWorld();
        if (w.isRemote) return;
        Entity en = e.getEntity();

        if (en instanceof AbstractSkeleton) {
            NBTTagCompound d = en.getEntityData();
            if (!d.getBoolean("StandRolled")) {
                d.setBoolean("StandRolled", true);
                Biome b = w.getBiome(en.getPosition());
                boolean desert = b == Biomes.DESERT || b == Biomes.DESERT_HILLS || b == Biomes.MUTATED_DESERT;
                if (w.rand.nextFloat() < (desert ? 0.23F : 0.05F)) d.setBoolean("HasStandArrow", true);
            }
        } else if (en instanceof EntityArrow) {
            Entity shooter = ((EntityArrow) en).shootingEntity;
            if (shooter instanceof AbstractSkeleton && shooter.getEntityData().getBoolean("HasStandArrow")) {
                en.getEntityData().setBoolean("StandArrow", true);
                shooter.getEntityData().setBoolean("HasStandArrow", false);
            }
        }
    }

    @SubscribeEvent
    public void onImpact(ProjectileImpactEvent e) {
        Entity a = e.getEntity();
        if (!(a instanceof EntityArrow) || a.world.isRemote) return;
        if (!a.getEntityData().getBoolean("StandArrow")) return;
        RayTraceResult r = e.getRayTraceResult();
        if (r != null && r.entityHit instanceof EntityPlayer) {
            EntityPlayer p = (EntityPlayer) r.entityHit;
            if (StandData.get(p) == 0) {
                StandData.grantRandom(p);
                a.getEntityData().setBoolean("StandArrow", false);
            }
        }
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent e) {
        EntityLivingBase l = e.getEntityLiving();
        if (l.world.isRemote) return;

        if (TimeStop.isFrozen(l)) {
            e.setCanceled(true);
            return;
        }

        // скелет подбирает брошенную метеоритную стрелу
        if (l instanceof AbstractSkeleton && l.ticksExisted % 10 == 0 && !l.getEntityData().getBoolean("HasStandArrow")) {
            for (EntityItem it : l.world.getEntitiesWithinAABB(EntityItem.class, l.getEntityBoundingBox().grow(1.5, 0.5, 1.5))) {
                if (it.getItem().getItem() == ModContent.METEOR_ARROW) {
                    ItemStack rest = it.getItem().copy();
                    rest.shrink(1);
                    if (rest.isEmpty()) it.setDead();
                    else it.setItem(rest);
                    l.getEntityData().setBoolean("HasStandArrow", true);
                    break;
                }
            }
        }
    }

    // ---------- тики мира ----------
    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent e) {
        if (e.world.isRemote) return;
        if (e.phase == TickEvent.Phase.START) {
            TimeStop.preTick(e.world);
        } else {
            TimeStop.postTick(e.world);
            KillerQueen.tick(e.world);
        }
    }

    @SubscribeEvent
    public void onNeighbor(BlockEvent.NeighborNotifyEvent e) {
        if (!e.getWorld().isRemote && TimeStop.isInside(e.getWorld(), e.getPos())) e.setCanceled(true);
    }
}
