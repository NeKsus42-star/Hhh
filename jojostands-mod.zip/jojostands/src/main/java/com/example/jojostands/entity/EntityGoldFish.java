package com.example.jojostands.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Рыба: прыгает к ближайшему мобу и убивает его. На суше живёт ~2 секунды. */
public class EntityGoldFish extends EntityLerp {
    private static final int LAND_LIFE = 45;
    private Entity owner;
    private EntityLivingBase target;
    private int life, landTicks;

    public EntityGoldFish(World w) {
        super(w);
        setSize(0.5F, 0.4F);
    }

    public static void summon(World w, double x, double y, double z, Entity owner) {
        if (owner == null || w.isRemote) return;
        EntityGoldFish f = new EntityGoldFish(w);
        f.owner = owner;
        f.setPosition(x, y + 0.3, z);
        w.spawnEntity(f);
        ((WorldServer) w).spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, x, y + 0.3, z, 12, 0.4, 0.4, 0.4, 0.0);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            lerpClient();
            return;
        }
        if (owner == null) {
            setDead();
            return;
        }
        life++;
        boolean water = isInWater();
        if (!water) landTicks++;
        if (landTicks > LAND_LIFE || life > 400) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.SMOKE_NORMAL, posX, posY, posZ, 8, 0.2, 0.2, 0.2, 0.02);
            setDead();
            return;
        }
        if (target == null || target.isDead || target.getHealth() <= 0) target = findTarget();
        if (target == null) {
            if (life > 30) setDead();
        } else {
            double dx = target.posX - posX;
            double dy = target.posY + target.height / 2.0 - posY;
            double dz = target.posZ - posZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist < 1.4) {
                kill();
                return;
            }
            if (water) {
                motionX = dx / dist * 0.4;
                motionY = dy / dist * 0.4;
                motionZ = dz / dist * 0.4;
            } else if (onGround) { // прыжок
                double h = Math.sqrt(dx * dx + dz * dz);
                if (h < 1.0E-4) h = 1.0;
                motionX = dx / h * 0.45;
                motionZ = dz / h * 0.45;
                motionY = 0.55;
            }
        }
        if (!water) motionY -= 0.08;
        move(MoverType.SELF, motionX, motionY, motionZ);
        if (onGround) {
            motionX *= 0.5;
            motionZ *= 0.5;
            if (motionY < 0) motionY = 0;
        } else if (!water) {
            motionX *= 0.98;
            motionZ *= 0.98;
        }
        motionY *= 0.98;
        if (motionX * motionX + motionZ * motionZ > 0.0004) {
            rotationYaw = (float) (MathHelper.atan2(-motionX, motionZ) * 180.0 / Math.PI);
        }
    }

    private void kill() {
        target.hurtResistantTime = 0;
        target.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, owner), 10000.0F);
        if (target.isEntityAlive() && !(target instanceof net.minecraft.entity.player.EntityPlayer)) {
            target.attackEntityFrom(DamageSource.OUT_OF_WORLD, 10000.0F);
        }
        ((WorldServer) world).spawnParticle(EnumParticleTypes.CRIT_MAGIC, target.posX, target.posY + target.height / 2, target.posZ, 20, 0.4, 0.4, 0.4, 0.2);
        setDead();
    }

    private EntityLivingBase findTarget() {
        EntityLivingBase best = null;
        double bd = Double.MAX_VALUE;
        for (EntityLiving e : world.getEntitiesWithinAABB(EntityLiving.class, getEntityBoundingBox().grow(24.0))) {
            if (e == owner || !e.isEntityAlive()) continue;
            if (e instanceof EntityTameable && ((EntityTameable) e).isTamed()) continue;
            double d = getDistanceSq(e) * (e instanceof IMob ? 1.0 : 4.0); // враждебные в приоритете
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }
}
