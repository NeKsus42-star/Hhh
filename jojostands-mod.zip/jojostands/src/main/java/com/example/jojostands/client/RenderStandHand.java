package com.example.jojostands.client;

import com.example.jojostands.JojoStands;
import com.example.jojostands.entity.EntityStandHand;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

public class RenderStandHand extends Render<EntityStandHand> {
    private static final ResourceLocation[] TEX = {
            tex("hand_killerqueen"), tex("hand_killerqueen"), tex("hand_starplatinum"), tex("hand_goldexperience")};
    private final ModelStandHand model = new ModelStandHand();

    private static ResourceLocation tex(String n) {
        return new ResourceLocation(JojoStands.MODID, "textures/entity/" + n + ".png");
    }

    public RenderStandHand(RenderManager m) {
        super(m);
    }

    @Override
    public void doRender(EntityStandHand e, double x, double y, double z, float yaw, float pt) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        float ry = e.prevRotationYaw + MathHelper.wrapDegrees(e.rotationYaw - e.prevRotationYaw) * pt;
        float rp = e.prevRotationPitch + (e.rotationPitch - e.prevRotationPitch) * pt;
        GlStateManager.rotate(180.0F - ry, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-rp, 1.0F, 0.0F, 0.0F);
        GlStateManager.enableRescaleNormal();
        GlStateManager.scale(-1.0F, -1.0F, 1.0F);
        bindEntityTexture(e);
        model.render(e, 0, 0, 0, 0, 0, 0.0625F * 1.4F);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.doRender(e, x, y, z, yaw, pt);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityStandHand e) {
        return TEX[MathHelper.clamp(e.getStandType(), 0, 3)];
    }
}
