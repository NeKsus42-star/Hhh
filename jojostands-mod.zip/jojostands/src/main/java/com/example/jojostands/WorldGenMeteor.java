package com.example.jojostands;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.fml.common.IWorldGenerator;

/** Падший метеорит: кратер с мицелием и блоком метеорита в центре. Любой биом, кроме воды. */
public class WorldGenMeteor implements IWorldGenerator {
    private static final int RARITY = 70; // 1 шанс из 70 на чанк
    private static final int R = 4;

    @Override
    public void generate(Random rand, int chunkX, int chunkZ, World world, IChunkGenerator gen, IChunkProvider prov) {
        if (world.provider.getDimension() != 0) return;
        if (rand.nextInt(RARITY) != 0) return;

        int cx = chunkX * 16 + 12 + rand.nextInt(8);
        int cz = chunkZ * 16 + 12 + rand.nextInt(8);
        BlockPos center = new BlockPos(cx, 0, cz);

        Biome biome = world.getBiome(center);
        if (BiomeDictionary.hasType(biome, BiomeDictionary.Type.OCEAN) || BiomeDictionary.hasType(biome, BiomeDictionary.Type.RIVER)) return;

        if (!solidGround(world.getBlockState(surface(world, center)))) return;

        // вода рядом -> не генерируем
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                if (dx * dx + dz * dz > R * R) continue;
                if (world.getBlockState(surface(world, new BlockPos(cx + dx, 0, cz + dz))).getMaterial().isLiquid()) return;
            }
        }

        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > R) continue;
                BlockPos surf = surface(world, new BlockPos(cx + dx, 0, cz + dz));
                if (!solidGround(world.getBlockState(surf))) continue;

                int depth = (int) Math.round(3.0 * (1.0 - d / (R + 0.5)));

                for (int k = 1; k <= 3; k++) { // убираем траву/цветы над кратером
                    BlockPos up = surf.up(k);
                    IBlockState us = world.getBlockState(up);
                    if (us.getMaterial() == Material.PLANTS || us.getMaterial() == Material.VINE || us.getMaterial() == Material.SNOW) {
                        world.setBlockState(up, Blocks.AIR.getDefaultState(), 2);
                    }
                }
                for (int i = 0; i < depth; i++) {
                    world.setBlockState(surf.down(i), Blocks.AIR.getDefaultState(), 2);
                }
                BlockPos floor = surf.down(depth);
                if (dx == 0 && dz == 0) {
                    world.setBlockState(floor, ModContent.METEOR_BLOCK.getDefaultState(), 2);
                } else {
                    world.setBlockState(floor, Blocks.MYCELIUM.getDefaultState(), 2);
                }
            }
        }
    }

    private static BlockPos surface(World w, BlockPos p) {
        return w.getTopSolidOrLiquidBlock(p).down();
    }

    private static boolean solidGround(IBlockState s) {
        Material m = s.getMaterial();
        return m == Material.GRASS || m == Material.GROUND || m == Material.SAND || m == Material.ROCK || m == Material.CLAY;
    }
}
