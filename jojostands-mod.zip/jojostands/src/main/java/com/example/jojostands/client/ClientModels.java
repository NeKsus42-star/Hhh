package com.example.jojostands.client;

import com.example.jojostands.JojoStands;
import com.example.jojostands.ModContent;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = JojoStands.MODID)
public class ClientModels {
    @SubscribeEvent
    public static void onModels(ModelRegistryEvent e) {
        reg(ModContent.METEOR_SHARD);
        reg(ModContent.METEOR_ARROW);
        reg(ModContent.METEOR_BLOCK_ITEM);
    }

    private static void reg(Item item) {
        ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
}
