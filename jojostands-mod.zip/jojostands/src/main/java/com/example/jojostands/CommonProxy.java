package com.example.jojostands;

public class CommonProxy {
    public void preInit() {}
    public void setClientStand(int stand) {}
}
