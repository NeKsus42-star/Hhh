package com.example.jojostands;

public class ClientState {
    public static int stand = 0;
}
