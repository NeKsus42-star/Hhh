package com.example.jojostands;

import com.example.jojostands.entity.EntityGoldFish;
import com.example.jojostands.entity.EntityGoldShot;
import com.example.jojostands.entity.EntityStandHand;
import com.example.jojostands.net.ModNetwork;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = JojoStands.MODID, name = "JoJo Stands", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class JojoStands {
    public static final String MODID = "jojostands";

    @Mod.Instance(MODID)
    public static JojoStands instance;

    @SidedProxy(clientSide = "com.example.jojostands.ClientProxy", serverSide = "com.example.jojostands.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        ModNetwork.init();
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "stand_hand"), EntityStandHand.class, "stand_hand", 0, this, 64, 1, true);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "gold_shot"), EntityGoldShot.class, "gold_shot", 1, this, 64, 5, true);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "gold_fish"), EntityGoldFish.class, "gold_fish", 2, this, 64, 1, true);
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        GameRegistry.registerWorldGenerator(new WorldGenMeteor(), 0);
        MinecraftForge.EVENT_BUS.register(new CommonEvents());
    }
}
