package com.example.jojostands.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/** Кулак у начала координат, предплечье уходит назад (+Z). */
public class ModelStandHand extends ModelBase {
    private final ModelRenderer fist;
    private final ModelRenderer arm;

    public ModelStandHand() {
        textureWidth = 64;
        textureHeight = 32;
        fist = new ModelRenderer(this, 0, 0);
        fist.addBox(-3F, -3F, -3F, 6, 6, 6);
        fist.setRotationPoint(0F, 0F, 0F);
        arm = new ModelRenderer(this, 0, 12);
        arm.addBox(-2F, -2F, 3F, 4, 4, 14);
        arm.setRotationPoint(0F, 0F, 0F);
    }

    @Override
    public void render(Entity e, float a, float b, float c, float d, float f, float scale) {
        fist.render(scale);
        arm.render(scale);
    }
}
