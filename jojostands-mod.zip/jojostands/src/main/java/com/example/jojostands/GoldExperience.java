package com.example.jojostands;

import com.example.jojostands.entity.EntityGoldShot;
import com.example.jojostands.entity.EntityStandHand;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;

public class GoldExperience {
    private static final Map<UUID, Long> CD = new HashMap<>();

    public static void shoot(EntityPlayerMP p, EntityStandHand hand) {
        long now = p.world.getTotalWorldTime();
        Long until = CD.get(p.getUniqueID());
        if (until != null && now < until) return;
        CD.put(p.getUniqueID(), now + 25);

        EntityGoldShot s = new EntityGoldShot(p.world, p);
        s.shoot(p, p.rotationPitch, p.rotationYaw, 0.0F, 2.2F, 0.0F);
        p.world.spawnEntity(s);
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.4F);
        hand.thrust(p);
    }
}
